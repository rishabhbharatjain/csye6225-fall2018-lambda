import boto3
import time
import secrets
import os
def lambda_handler(event, context):
    username = event['Records'][0]['Sns']['Message']
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('csye6225')
    response_table=table.scan()
    epoch_time = int(time.time()) +1200
    d_name= os.environ['d_name']
    s_name=os.environ['s_id']
    flag=0
    for i in response_table["Items"]:
        if i["username"] == username:
            flag=1
            print(i["username"])
            break
        
    if flag==0:
        token=secrets.token_hex(16)  
        domain_name=d_name
        SENDER = s_name
        RECIPIENT = username
        resetlink = "http://"+domain_name+"/reset?email="+username+"&token="+token
        #print ("resetlink is")
        #print(resetlink)
        #print(type(resetlink))
        AWS_REGION = "us-east-1"
        SUBJECT = "EMAIL RESET"
        BODY_TEXT =("RESET")
        BODY_HTML="""<html>
        <head></head>
        <body>
        <h1>Password reset is given link below</h1>
        <p>The reset link for your username {UserN} is </p>
        <p>{URL} </p>
        </body>
        </html>
              """ 
        new_message =BODY_HTML.format(UserN=username,URL=resetlink)
        CHARSET = "UTF-8"
        client = boto3.client('ses',region_name=AWS_REGION)
        try:
            response = client.send_email(
                Destination={
                    'ToAddresses': [
                            RECIPIENT,
                    ],
                },
                Message={
                    'Body': {
                        'Html': {
                            'Charset': CHARSET,
                            'Data': new_message,
                        },
                        'Text': {
                            'Charset': CHARSET,
                            'Data': BODY_TEXT,
                        },
                    },
                    'Subject': {
                        'Charset': CHARSET,
                        'Data': SUBJECT,
                    },
                },
                Source=SENDER,
            )
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print("Email sent!!!! Message ID:"),
            print(response['MessageId']) 
        response = table.put_item(
            Item={
                'token' : token,
                'username': username,
                'time': epoch_time,
            }
        )
        print("data put succeeded:")
    else:
        print("user exists")